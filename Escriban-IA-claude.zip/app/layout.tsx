import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Libredeuda · Servicios e impuestos",
  description: "Suministros, impuestos y facturas por provincia y ciudad.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}


